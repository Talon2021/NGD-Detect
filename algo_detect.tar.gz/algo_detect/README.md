算法输入 1024 * 1024 yuv420sp
模型路径 /root/app/ai/yolov8_seg.rknn 
labal路径 /root/app/ai/gas_labels_list.txt

c162143a27d6a539b6df99803659d4b7  algo_detect/lib/libcurl.so
c162143a27d6a539b6df99803659d4b7  algo_detect/lib/libcurl.so.4
c162143a27d6a539b6df99803659d4b7  algo_detect/lib/libcurl.so.4.8.0
9f3d6ca9adee2b8ba9802dd4046e6cbc  algo_detect/lib/libgpiod.so
9f3d6ca9adee2b8ba9802dd4046e6cbc  algo_detect/lib/libgpiod.so.3
9f3d6ca9adee2b8ba9802dd4046e6cbc  algo_detect/lib/libgpiod.so.3.1.1
3dbf3fa8662949ced4e0bd931657a50c  algo_detect/lib/libip.so
8583b69f08aa2f3c49ba4b16b7dcf848  algo_detect/lib/libjpsdk.so
0bd5a9a525fdcf2f9e91f55ef02416dc  algo_detect/lib/libmahony.so
d487f39eea1fa9b327e6615cbf8d8c1d  algo_detect/lib/libMidLayer.so
f774155abfe7355d9a62ba11ba58c820  algo_detect/lib/libminini.so
dd5cd23438a176bd718b6769d6c76c42  algo_detect/lib/libmqtt.so
ce68032e112935d3134d048c70153c04  algo_detect/lib/libnetwork.so
fac578d390b934ba392b25a855e37875  algo_detect/lib/librga.so
1fa6cb4fd7e4c871c27e5daef462b024  algo_detect/lib/librknnrt.so
3a847b257167e80a57ff3a3f6a09761e  algo_detect/lib/libz.so
3a847b257167e80a57ff3a3f6a09761e  algo_detect/lib/libz.so.1
3a847b257167e80a57ff3a3f6a09761e  algo_detect/lib/libz.so.1.3.1

3a5f3d5df3f63606d66120754541f636  algo_detect/model/yolov8_seg.rknn